const aws = require('aws-sdk')
const ses = new aws.SES({
  region: 'us-west-2',
})

export default function() {
  console.log('Incoming: ', event)

  const eParams = {
    Destination: {
      ToAddresses: ['vchatzipan@gmail.com'],
    },
    Message: {
      Body: {
        Text: {
          Data: 'Hey! What is up?',
        },
      },
      Subject: {
        Data: 'Email Subject!!!',
      },
    },
    Source: 'mr.jim@gmail.com',
  }

  console.log('===SENDING EMAIL===')
  const email = ses.sendEmail(eParams, function(err, data) {
    if (err) console.log(err)
    else {
      console.log('===EMAIL SENT===')
      console.log(data)

      console.log('EMAIL CODE END')
      console.log('EMAIL: ', email)
      context.succeed(event)
    }
  })
}
